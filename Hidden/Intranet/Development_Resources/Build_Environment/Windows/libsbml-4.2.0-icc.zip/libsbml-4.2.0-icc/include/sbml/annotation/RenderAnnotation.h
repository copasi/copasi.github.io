/**
 * @file    RenderAnnotation.h
 * @brief   render annotation I/O
 * @author  Ralph Gauges
 *
 */
/* Copyright 2003 California Institute of Technology and Japan Science and
 * Technology Corporation.
 *
 * This library is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation.  A copy of the license agreement is
 * provided in the file named "LICENSE.txt" included with this software
 * distribution.  It is also available online at
 * http://sbml.org/software/libsbml/license.html
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA.
 *
 * The original code contained here was initially developed by:
 *
 *     Ralph Gauges
 *     Group for the modeling of biological processes 
 *     University of Heidelberg
 *     Im Neuenheimer Feld 267
 *     69120 Heidelberg
 *     Germany
 *
 *     mailto:ralph.gauges@bioquant.uni-heidelberg.de
 *
 * Contributor(s):
 */


#ifndef RenderAnnotation_h
#define RenderAnnotation_h


#include <sbml/common/extern.h>
#include <sbml/common/sbmlfwd.h>

#include <sbml/xml/XMLAttributes.h>

#ifdef USE_RENDER
#include <sbml/layout/render/GlobalRenderInformation.h>
#include <sbml/layout/render/LocalRenderInformation.h>
#endif // USE_RENDER

#ifdef __cplusplus

#include <limits>
#include <iomanip>
#include <string>
#include <sstream>
#include <map>

#include <cstdlib>

LIBSBML_CPP_NAMESPACE_BEGIN

#ifdef USE_RENDER // make the functions inaccesible when the render extension is not used
class Layout;
class Model;

/**
 * takes an annotation that has been read into the model
 * identifies the render elements
 * and creates a List of global render information objects from the annotation
 */
LIBSBML_EXTERN
void parseGlobalRenderAnnotation(XMLNode * annotation, ListOfLayouts* pLOL);

/**
 * Takes an XMLNode and tries to find the layout annotation node and deletes it if it was found.
 */
LIBSBML_EXTERN
XMLNode* deleteGlobalRenderAnnotation(XMLNode* pAnnotation);

/**
 * Creates an XMLNode that represents the layouts of the model from the given Model object.
 */
 LIBSBML_EXTERN
 XMLNode* parseGlobalRenderInformation(const ListOfLayouts* pList);
 

/**
 * takes an annotation that has been read into the model
 * identifies the render elements
 * and creates a List of global render information objects from the annotation
 */
LIBSBML_EXTERN
void parseLocalRenderAnnotation(XMLNode * annotation, Layout* pLayout);

/**
 * Takes an XMLNode and tries to find the layout annotation node and deletes it if it was found.
 */
LIBSBML_EXTERN
XMLNode* deleteLocalRenderAnnotation(XMLNode* pAnnotation);

/**
 * Creates an XMLNode that represents the layouts of the model from the given Model object.
 */
LIBSBML_EXTERN
XMLNode* parseLocalRenderInformation(const Layout* pLayout);
 
/**
 * This method adds a correction term to text elements from the old spec so that the text placement
 * is improved.
 */
LIBSBML_EXTERN
void fixTextElements(RenderInformationBase* pRenderInfo);
 
/**
 * This method adds a correction term to text elements from the old spec so that the text placement
 * is improved.
 */
LIBSBML_EXTERN
void fixTextElements(LocalRenderInformation* pRenderInfo);
 
/**
 * This method adds a correction term to text elements from the old spec so that the text placement
 * is improved.
 */
LIBSBML_EXTERN
void fixTextElements(GlobalRenderInformation* pRenderInfo);

/**
 * This method adds a correction term to text elements from the old spec so that the text placement
 * is improved.
 */
LIBSBML_EXTERN
void fixTextElements(Group* pGroup,RelAbsVector fontSize=RelAbsVector(0.0,0.0));

/**
 * This method creates a string with namespace attributes
 * so that we can add them to the XML content of a node.
 * This is needed so that the parser will have all namespace definitions that might occur
 * in a given element.
 */
LIBSBML_EXTERN
std::string createNamespaceAttributes(const std::map<std::string,std::string>& namespaceMap);

#endif // USE_RENDER

LIBSBML_CPP_NAMESPACE_END

#endif  /* __cplusplus */

#endif  /** RenderAnnotation_h **/

